package dev.jry.velora;

import dev.jry.velora.config.VeloraConfig;
import dev.jry.velora.config.DisplayPattern;
import dev.jry.velora.gui.VeloraConfigScreen;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.class_2960;
import net.minecraft.class_304;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;

/**
 * Velora entrypoint (client only).
 *
 * <p>Velora is a purely visual mod. Nothing in here talks to the server, and nothing
	 * touches inventories, item stacks or packets. It only loads the local config and
	 * registers Velora's client-side keybindings.
 */
public class VeloraClient implements ClientModInitializer {
	public static final String MOD_ID = "velora";
	private static final class_304.class_11900 KEY_CATEGORY =
			class_304.class_11900.method_74698(class_2960.method_60655("velora", "key.categories.velora"));

	private static class_304 openSettingsKey;
	private static class_304 togglePatternKey;

	@Override
	public void onInitializeClient() {
		VeloraConfig.load();

		// Default: V. Vanilla Minecraft does not bind it. It can be changed in
		// Options -> Controls under the "Velora" category.
		openSettingsKey = KeyBindingHelper.registerKeyBinding(new class_304(
				"key.velora.open_settings",
				class_3675.class_307.field_1668,
				GLFW.GLFW_KEY_V,
				KEY_CATEGORY
		));
		togglePatternKey = KeyBindingHelper.registerKeyBinding(new class_304(
				"key.velora.toggle_pattern",
				class_3675.class_307.field_1668,
				GLFW.GLFW_KEY_P,
				KEY_CATEGORY
		));

		ClientTickEvents.END_CLIENT_TICK.register(client -> {
			while (openSettingsKey.method_1436()) {
				if (client.field_1755 == null) {
					client.method_1507(new VeloraConfigScreen(null));
				}
			}
			while (togglePatternKey.method_1436()) {
				if (client.field_1755 == null) {
					VeloraConfig config = VeloraConfig.get();
					config.pattern = config.pattern == DisplayPattern.PATTERN_A
							? DisplayPattern.NORMAL
							: DisplayPattern.PATTERN_A;
					config.winLoseEnabled = !config.winLoseEnabled;
					VeloraConfig.save();
				}
			}
		});
	}
}
