package dev.jry.velora.mixin;

import dev.jry.velora.display.DisplayResolver;
import dev.jry.velora.display.SlotDisplay;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

import java.util.Optional;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_329;

@Mixin(class_329.class)
public abstract class InGameHudMixin {
	@Redirect(
			method = "renderHeldItemTooltip",
			at = @At(value = "INVOKE", target = "Lnet/minecraft/item/ItemStack;getName()Lnet/minecraft/text/Text;")
	)
	private class_2561 velora$useDisplayName(class_1799 stack) {
		class_310 client = class_310.method_1551();
		if (client.field_1724 != null) {
			int position = client.field_1724.method_31548().method_67532();
			Optional<SlotDisplay> display = DisplayResolver.resolve(stack, position);
			if (display.isPresent()) {
				return class_2561.method_43470(display.get().label());
			}
		}
		return stack.method_7964();
	}
}