package dev.jry.velora.mixin;

import dev.jry.velora.display.DisplayResolver;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

import java.util.Optional;
import net.minecraft.class_10442;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_9331;
import net.minecraft.class_9334;

@Mixin(class_10442.class)
public abstract class ItemModelManagerMixin {
	@WrapOperation(
			method = "update(Lnet/minecraft/client/render/item/ItemRenderState;Lnet/minecraft/item/ItemStack;Lnet/minecraft/item/ItemDisplayContext;Lnet/minecraft/world/World;Lnet/minecraft/util/HeldItemContext;I)V",
			at = @At(value = "INVOKE", target = "Lnet/minecraft/item/ItemStack;get(Lnet/minecraft/component/ComponentType;)Ljava/lang/Object;")
	)
	private Object velora$useLoseItemModel(class_1799 stack, class_9331<?> type, Operation<Object> original) {
		Object originalModelId = original.call(stack, type);
		if (type == class_9334.field_54199) {
			Optional<class_2960> modelId = DisplayResolver.winLoseModelId(stack);
			if (modelId.isPresent()) {
				return modelId.get();
			}
		}
		return originalModelId;
	}
}