package dev.jry.velora.mixin;

import dev.jry.velora.display.DisplayResolver;
import dev.jry.velora.display.SlotDisplay;
import dev.jry.velora.display.VeloraRenderer;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import net.minecraft.class_1703;
import net.minecraft.class_1735;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_437;
import net.minecraft.class_465;

/**
 * Render-only hooks into every container screen.
 *
 * <p>Both injections only change what is DRAWN. Neither touches slot contents, the screen
 * handler, click handling or packets, so clicking a slot still acts on the real server slot.
 * Which slots get restyled is decided by {@link DisplayResolver}.
 */
@Mixin(class_465.class)
public abstract class HandledScreenMixin<T extends class_1703> extends class_437 {
	@Shadow
	@Final
	protected T handler;

	@Shadow
	protected class_1735 focusedSlot;

	protected HandledScreenMixin(class_2561 title) {
		super(title);
	}

	/**
	 * Replaces only the FIRST tooltip line (the item name) with the local label. A copy of
	 * the tooltip text is edited; the real ItemStack and its name are left alone.
	 */
	@Inject(method = "drawMouseoverTooltip", at = @At("HEAD"), cancellable = true)
	private void velora$drawTooltip(class_332 context, int x, int y, CallbackInfo ci) {
		if (this.focusedSlot == null || !this.handler.method_34255().method_7960()) {
			return; // vanilla shows nothing here either
		}
		class_465<?> self = (class_465<?>) (Object) this;
		Optional<SlotDisplay> display = DisplayResolver.resolve(self, this.focusedSlot);
		if (display.isEmpty()) {
			return; // not ours: let vanilla draw its normal tooltip
		}

		List<class_2561> lines = new ArrayList<>(this.method_25408(this.field_22787, this.focusedSlot.method_7677()));
		if (lines.isEmpty()) {
			lines.add(class_2561.method_43473());
		}
		lines.set(0, class_2561.method_43470(display.get().label()));

		context.method_51434(this.field_22793, lines, x, y);
		VeloraRenderer.drawMapPreview(context, x, y, this.field_22790, display.get());
		ci.cancel();
	}
}
