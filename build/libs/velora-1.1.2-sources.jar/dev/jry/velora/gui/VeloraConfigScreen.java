package dev.jry.velora.gui;

import dev.jry.velora.config.DisplayMode;
import dev.jry.velora.config.DisplayPattern;
import dev.jry.velora.config.VeloraConfig;
import dev.jry.velora.display.MapArt;
import dev.jry.velora.display.VeloraRenderer;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_5244;
import net.minecraft.class_7923;

/**
 * Velora's settings screen. Every change is saved immediately, so there is no JSON editing
 * and nothing is lost if the game closes.
 */
public class VeloraConfigScreen extends class_437 {
	private static final int BUTTON_WIDTH = 220;
	private static final int BUTTON_HEIGHT = 20;
	private static final int ROW_STEP = 24;
	private static final int FIRST_ROW_Y = 34;
	private static final int CELL = 14;

	private final class_437 parent;

	private class_4185 modeButton;
	private class_4185 item1Button;
	private class_4185 item2Button;
	private class_4185 patternButton;
	private class_4185 overrideButton;
	private class_4185 winItemButton;
	private class_4185 loseItemButton;

	public VeloraConfigScreen(class_437 parent) {
		super(class_2561.method_43470("Velora Settings"));
		this.parent = parent;
	}

	@Override
	protected void method_25426() {
		VeloraConfig config = VeloraConfig.get();
		int x = this.field_22789 / 2 - BUTTON_WIDTH / 2;
		int y = FIRST_ROW_Y;

		modeButton = method_37063(class_4185.method_46430(class_2561.method_43473(), button -> {
			config.mode = config.mode.next();
			VeloraConfig.save();
			refresh();
		}).method_46434(x, y, BUTTON_WIDTH, BUTTON_HEIGHT).method_46431());
		y += ROW_STEP;

		item1Button = method_37063(class_4185.method_46430(class_2561.method_43473(), button ->
				this.field_22787.method_1507(new ItemPickerScreen(
						this,
						class_2561.method_43470("Select Item 1 (Lower Numbers)"),
						config.item1Id(),
						config.item2Id(),
						id -> config.setItem1(id))))
				.method_46434(x, y, BUTTON_WIDTH, BUTTON_HEIGHT).method_46431());
		y += ROW_STEP;

		item2Button = method_37063(class_4185.method_46430(class_2561.method_43473(), button ->
				this.field_22787.method_1507(new ItemPickerScreen(
						this,
						class_2561.method_43470("Select Item 2 (Higher Numbers)"),
						config.item2Id(),
						config.item1Id(),
						id -> config.setItem2(id))))
				.method_46434(x, y, BUTTON_WIDTH, BUTTON_HEIGHT).method_46431());
		y += ROW_STEP;

		patternButton = method_37063(class_4185.method_46430(class_2561.method_43473(), button -> {
			config.pattern = config.pattern.next();
			VeloraConfig.save();
			refresh();
		}).method_46434(x, y, BUTTON_WIDTH, BUTTON_HEIGHT).method_46431());
		y += ROW_STEP;

		overrideButton = method_37063(class_4185.method_46430(class_2561.method_43473(), button -> {
			config.map9LocalOverride = !config.map9LocalOverride;
			VeloraConfig.save();
			refresh();
		}).method_46434(x, y, BUTTON_WIDTH, BUTTON_HEIGHT).method_46431());
		y += ROW_STEP;
		y += 12;

		winItemButton = method_37063(class_4185.method_46430(class_2561.method_43473(), button ->
				this.field_22787.method_1507(new ItemPickerScreen(
						this,
						class_2561.method_43470("Select WIN Item"),
						config.winItemId(),
						config.loseItemId(),
						config::setWinItem)))
				.method_46434(x, y, BUTTON_WIDTH, BUTTON_HEIGHT).method_46431());
		y += ROW_STEP;

		loseItemButton = method_37063(class_4185.method_46430(class_2561.method_43473(), button ->
				this.field_22787.method_1507(new ItemPickerScreen(
						this,
						class_2561.method_43470("Select LOSE Item"),
						config.loseItemId(),
						config.winItemId(),
						config::setLoseItem)))
				.method_46434(x, y, BUTTON_WIDTH, BUTTON_HEIGHT).method_46431());

		method_37063(class_4185.method_46430(class_5244.field_24334, button -> method_25419())
				.method_46434(x, this.field_22790 - 28, BUTTON_WIDTH, BUTTON_HEIGHT).method_46431());

		refresh();
	}

	/** Updates button labels and which buttons apply to the current mode. */
	private void refresh() {
		VeloraConfig config = VeloraConfig.get();
		boolean itemMode = config.mode == DisplayMode.ITEM_NAMES;

		modeButton.method_25355(class_2561.method_43470("Display Mode: " + config.mode.label()));
		item1Button.method_25355(class_2561.method_43470("Item 1 (Lower Numbers): " + itemName(config.item1Id())));
		item2Button.method_25355(class_2561.method_43470("Item 2 (Higher Numbers): " + itemName(config.item2Id())));
		patternButton.method_25355(class_2561.method_43470("Display Pattern: " + config.pattern.label()));
		overrideButton.method_25355(class_2561.method_43470("Map 9 Local Override: " + (config.map9LocalOverride ? "ON" : "OFF")));
		winItemButton.method_25355(class_2561.method_43470("WIN Item: " + itemName(config.winItemId())));
		loseItemButton.method_25355(class_2561.method_43470("LOSE Item: " + itemName(config.loseItemId())));

		// Item pickers only matter in Item Names mode, the override only in Maps mode.
		item1Button.field_22763 = itemMode;
		item2Button.field_22763 = itemMode;
		overrideButton.field_22763 = !itemMode;
	}

	private static String itemName(class_2960 id) {
		return id == null ? "?" : class_7923.field_41178.method_63535(id).method_63680().getString();
	}

	@Override
	public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
		super.method_25394(context, mouseX, mouseY, delta);
		context.method_27534(this.field_22793, this.field_22785, this.field_22789 / 2, 14, 0xFFFFFF);
		context.method_27534(this.field_22793,
				class_2561.method_43470("WIN / LOSE ITEMS (P toggle: " + (VeloraConfig.get().winLoseEnabled ? "ON" : "OFF") + ")"),
				this.field_22789 / 2, FIRST_ROW_Y + 5 * ROW_STEP + 2, 0xFFFFFF);
		if (this.field_22790 >= 360) {
			drawActiveMapping(context);
		}
	}

	/** Shows what the dispenser's nine slots will look like with the current settings. */
	private void drawActiveMapping(class_332 context) {
		VeloraConfig config = VeloraConfig.get();
		int centerX = this.field_22789 / 2;
		int y = FIRST_ROW_Y + 8 * ROW_STEP + 4;
		int left = centerX - BUTTON_WIDTH / 2;
		int cellsStart = left + 70;

		context.method_27534(this.field_22793,
				class_2561.method_43470("Active mapping (real slot → shown as)"), centerX, y, 0xFFAAAAAA);
		y += 14;

		drawRow(context, "Real slot", left, cellsStart, y, 0xFF888888, DisplayPattern.NORMAL::number);
		y += 12;

		if (config.mode == DisplayMode.ITEM_NAMES) {
			drawRow(context, "Item 1", left, cellsStart, y, 0xFFFFFF55, config.pattern::lowerNumber);
			y += 12;
			drawRow(context, "Item 2", left, cellsStart, y, 0xFF55FFFF, config.pattern::higherNumber);
		} else {
			drawRow(context, "Map art", left, cellsStart, y, 0xFFFFFF55, config.pattern::number);
			y += 13;
			for (int i = 0; i < DisplayPattern.SLOT_COUNT; i++) {
				class_2960 art = MapArt.texture(config.pattern.number(i), config.map9LocalOverride);
				VeloraRenderer.drawArt(context, art, cellsStart + i * CELL + 1, y, 12);
			}
		}
	}

	private void drawRow(class_332 context, String name, int left, int cellsStart, int y, int color,
						 java.util.function.IntUnaryOperator numberForSlot) {
		context.method_27535(this.field_22793, class_2561.method_43470(name), left, y, color);
		for (int i = 0; i < DisplayPattern.SLOT_COUNT; i++) {
			context.method_27534(this.field_22793,
					class_2561.method_43470(String.valueOf(numberForSlot.applyAsInt(i))),
					cellsStart + i * CELL + CELL / 2, y, color);
		}
	}

	@Override
	public void method_25419() {
		this.field_22787.method_1507(parent);
	}
}
