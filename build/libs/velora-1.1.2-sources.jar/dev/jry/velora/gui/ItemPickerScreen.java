package dev.jry.velora.gui;

import dev.jry.velora.config.VeloraConfig;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.function.Consumer;
import net.minecraft.class_124;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_5244;
import net.minecraft.class_7923;

/**
 * Searchable grid of every item in the game. The item that is already used for the other
 * slot role is disabled, so Item 1 and Item 2 can never be the same.
 */
public class ItemPickerScreen extends class_437 {
	private static final int COLUMNS = 9;
	private static final int CELL = 22;
	private static final int GRID_TOP = 56;

	private final class_437 parent;
	private final class_2960 current;
	private final class_2960 disallowed;
	private final Consumer<class_2960> onPick;
	private final List<class_1792> allItems = new ArrayList<>();

	private record Cell(class_1792 item, class_1799 stack, class_2960 id, class_4185 button) {
	}

	private final List<Cell> cells = new ArrayList<>();
	private List<class_1792> filtered = List.of();
	private class_342 search;
	private class_4185 previousButton;
	private class_4185 nextButton;
	private String query = "";
	private int page;
	private int rows;

	public ItemPickerScreen(class_437 parent, class_2561 title, class_2960 current, class_2960 disallowed, Consumer<class_2960> onPick) {
		super(title);
		this.parent = parent;
		this.current = current;
		this.disallowed = disallowed;
		this.onPick = onPick;

		class_7923.field_41178.method_10220()
				.filter(item -> item != class_1802.field_8162)
				.sorted(Comparator.comparing(item -> class_7923.field_41178.method_10221(item).toString()))
				.forEach(allItems::add);
	}

	@Override
	protected void method_25426() {
		cells.clear(); // the old buttons were dropped with the previous layout
		rows = Math.max(2, Math.min(6, (this.field_22790 - GRID_TOP - 70) / CELL));
		int gridWidth = COLUMNS * CELL;
		int left = this.field_22789 / 2 - gridWidth / 2;
		int pagerY = GRID_TOP + rows * CELL + 4;

		search = new class_342(this.field_22793, this.field_22789 / 2 - 100, 28, 200, 18, class_2561.method_43470("Search"));
		search.method_47404(class_2561.method_43470("Search items..."));
		search.method_1852(query);
		search.method_1863(text -> {
			query = text;
			page = 0;
			applyFilter();
		});
		method_37063(search);
		method_48265(search);

		previousButton = method_37063(class_4185.method_46430(class_2561.method_43470("<"), button -> {
			page--;
			rebuildGrid();
		}).method_46434(left, pagerY, 20, 20).method_46431());
		nextButton = method_37063(class_4185.method_46430(class_2561.method_43470(">"), button -> {
			page++;
			rebuildGrid();
		}).method_46434(left + gridWidth - 20, pagerY, 20, 20).method_46431());

		method_37063(class_4185.method_46430(class_5244.field_24335, button -> method_25419())
				.method_46434(this.field_22789 / 2 - 100, this.field_22790 - 28, 200, 20).method_46431());

		applyFilter();
	}

	private void applyFilter() {
		String needle = query.toLowerCase(Locale.ROOT).trim();
		filtered = allItems.stream()
				.filter(item -> needle.isEmpty()
						|| class_7923.field_41178.method_10221(item).toString().contains(needle)
						|| item.method_63680().getString().toLowerCase(Locale.ROOT).contains(needle))
				.toList();
		rebuildGrid();
	}

	private void rebuildGrid() {
		for (Cell cell : cells) {
			method_37066(cell.button());
		}
		cells.clear();

		int pageSize = COLUMNS * rows;
		int pageCount = Math.max(1, (filtered.size() + pageSize - 1) / pageSize);
		page = Math.max(0, Math.min(page, pageCount - 1));

		int left = this.field_22789 / 2 - (COLUMNS * CELL) / 2;
		int start = page * pageSize;
		int end = Math.min(filtered.size(), start + pageSize);
		for (int i = start; i < end; i++) {
			class_1792 item = filtered.get(i);
			class_2960 id = class_7923.field_41178.method_10221(item);
			int slot = i - start;
			int x = left + (slot % COLUMNS) * CELL;
			int y = GRID_TOP + (slot / COLUMNS) * CELL;

			class_4185 button = class_4185.method_46430(class_2561.method_43473(), b -> pick(id))
					.method_46434(x, y, CELL - 2, CELL - 2).method_46431();
			button.field_22763 = !id.equals(disallowed);
			method_37063(button);
			cells.add(new Cell(item, new class_1799(item), id, button));
		}

		previousButton.field_22763 = page > 0;
		nextButton.field_22763 = page < pageCount - 1;
	}

	private void pick(class_2960 id) {
		if (id.equals(disallowed)) {
			return;
		}
		onPick.accept(id);
		VeloraConfig.save();
		method_25419();
	}

	@Override
	public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
		super.method_25394(context, mouseX, mouseY, delta);
		context.method_27534(this.field_22793, this.field_22785, this.field_22789 / 2, 12, 0xFFFFFF);

		for (Cell cell : cells) {
			class_4185 button = cell.button();
			context.method_51427(cell.stack(), button.method_46426() + 1, button.method_46427() + 1);
			if (cell.id().equals(current)) {
				context.method_73198(button.method_46426() - 1, button.method_46427() - 1, button.method_25368() + 2, button.method_25364() + 2, 0xFFFFFF55);
			}
		}

		int pageSize = COLUMNS * rows;
		int pageCount = Math.max(1, (filtered.size() + pageSize - 1) / pageSize);
		context.method_27534(this.field_22793,
				class_2561.method_43470("Page " + (page + 1) + "/" + pageCount + "  (" + filtered.size() + " items)"),
				this.field_22789 / 2, GRID_TOP + rows * CELL + 10, 0xFFAAAAAA);

		for (Cell cell : cells) {
			if (cell.button().method_25405(mouseX, mouseY)) {
				List<class_2561> tooltip = new ArrayList<>();
				tooltip.add(cell.item().method_63680());
				tooltip.add(class_2561.method_43470(cell.id().toString()).method_27692(class_124.field_1080));
				if (cell.id().equals(disallowed)) {
					tooltip.add(class_2561.method_43470("Already used by the other item").method_27692(class_124.field_1061));
				}
				context.method_51434(this.field_22793, tooltip, mouseX, mouseY);
				break;
			}
		}
	}

	@Override
	public void method_25419() {
		this.field_22787.method_1507(parent);
	}
}
