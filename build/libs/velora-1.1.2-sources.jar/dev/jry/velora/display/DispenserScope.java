package dev.jry.velora.display;

import dev.jry.velora.config.DisplayPattern;
import java.util.OptionalInt;
import net.minecraft.class_1716;
import net.minecraft.class_1735;
import net.minecraft.class_2588;
import net.minecraft.class_465;

/**
 * Covers the nine slots of a dispenser.
 *
 * <p>Vanilla uses the same 3x3 screen handler for droppers, so a screen titled with the
 * vanilla dropper name is excluded. Servers often rename dispensers, so the title is not
 * used to require "Dispenser".
 */
public final class DispenserScope implements DisplayScope {
	@Override
	public OptionalInt positionOf(class_465<?> screen, class_1735 slot) {
		if (!(screen.method_17577() instanceof class_1716)) {
			return OptionalInt.empty();
		}
		if (screen.method_25440().method_10851() instanceof class_2588 title
				&& "container.dropper".equals(title.method_11022())) {
			return OptionalInt.empty();
		}
		// In this handler the container's nine slots come first (ids 0-8); the
		// player's inventory follows and is never touched.
		if (slot.field_7874 >= 0 && slot.field_7874 < DisplayPattern.SLOT_COUNT) {
			return OptionalInt.of(slot.field_7874);
		}
		return OptionalInt.empty();
	}
}
