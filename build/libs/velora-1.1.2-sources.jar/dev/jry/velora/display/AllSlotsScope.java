package dev.jry.velora.display;

import java.util.OptionalInt;
import net.minecraft.class_1716;
import net.minecraft.class_1735;
import net.minecraft.class_2588;
import net.minecraft.class_465;

/**
 * Applies the display pattern to inventory slots, repeating every nine handler slots.
 *
 * <p>When a vanilla dropper is open, its own nine container slots are deliberately
 * left with vanilla display names. Player inventory/hotbar slots remain eligible for
 * the normal local display pattern. Slot contents and slot order are never changed.
 */
public final class AllSlotsScope implements DisplayScope {
    @Override
    public OptionalInt positionOf(class_465<?> screen, class_1735 slot) {
        if (slot.field_7874 < 0) {
            return OptionalInt.empty();
        }

        boolean dropperScreen = screen.method_17577() instanceof class_1716
                && screen.method_25440().method_10851() instanceof class_2588 title
                && "container.dropper".equals(title.method_11022());

        // A dropper's container slots are 0-8. Leave those completely vanilla.
        if (dropperScreen && slot.field_7874 < 9) {
            return OptionalInt.empty();
        }

        return OptionalInt.of(slot.field_7874 % 9);
    }
}
