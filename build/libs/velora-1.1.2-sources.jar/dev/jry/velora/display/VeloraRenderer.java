package dev.jry.velora.display;

import net.minecraft.class_10799;
import net.minecraft.class_2960;
import net.minecraft.class_332;

/**
 * Draws Velora's local overlays. Every method only issues GUI draw calls; none of them
 * touches an ItemStack, a slot or the network.
 */
public final class VeloraRenderer {
	/** Source size of the bundled map art PNGs. */
	private static final int ART_SIZE = 128;

	private VeloraRenderer() {
	}

	/** Larger map preview shown next to the cursor while hovering a restyled map. */
	public static void drawMapPreview(class_332 context, int cursorX, int cursorY, int screenHeight, SlotDisplay display) {
		if (display.art() == null) {
			return;
		}
		int size = 64;
		int x = cursorX + 12;
		int y = Math.min(cursorY + 12, screenHeight - size - 4);
		context.method_51448().pushMatrix();
		context.method_51448().translate(0.0f, 0.0f);
		drawArt(context, display.art(), x, y, size);
		context.method_51448().popMatrix();
	}

	/** Draws the whole 128x128 art texture scaled to {@code size} x {@code size}. */
	public static void drawArt(class_332 context, class_2960 texture, int x, int y, int size) {
		context.method_52706(class_10799.field_56883, texture, x, y, size, size);
	}
}
