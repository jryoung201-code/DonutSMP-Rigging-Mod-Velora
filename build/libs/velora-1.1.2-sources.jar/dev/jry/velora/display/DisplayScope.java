package dev.jry.velora.display;

import java.util.OptionalInt;
import net.minecraft.class_1735;
import net.minecraft.class_465;

/**
 * Decides which containers Velora may restyle.
 *
 * <p>Each scope maps a handled-screen slot to one of the repeating display positions.
 * Scopes are registered by {@link DisplayResolver}.
 */
public interface DisplayScope {
	/**
	 * @return the logical position (0-based) of {@code slot} inside the supported
	 *         container, or empty if this scope does not cover the screen or slot.
	 */
	OptionalInt positionOf(class_465<?> screen, class_1735 slot);
}
