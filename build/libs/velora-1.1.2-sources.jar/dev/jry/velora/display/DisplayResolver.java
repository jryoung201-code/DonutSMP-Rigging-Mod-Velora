package dev.jry.velora.display;

import dev.jry.velora.config.DisplayPattern;
import dev.jry.velora.config.VeloraConfig;
import java.util.List;
import java.util.Optional;
import java.util.OptionalInt;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2960;
import net.minecraft.class_465;
import net.minecraft.class_7923;
import net.minecraft.class_9209;
import net.minecraft.class_9334;

/**
 * The heart of Velora's client-side rendering system.
 *
 * <p>ACTUAL DATA (the real ItemStack, item id, map id, slot, server state) is only ever
 * READ here. DISPLAY DATA ({@link SlotDisplay}) is what comes out. The renderer draws that
 * on top of the normal slot, locally. Nothing is written back: no stack is copied into the
 * handler, no packet is built, and click handling is never involved, so a click on a slot
 * always acts on the real server slot.
 *
 * <p>The stack is re-read on every call. Nothing is cached, so server inventory updates are
 * picked up on the next frame.
 *
 * <p>Items are recognized by their real identity (item registry id, or the map id component).
 * Item Names mode reads the numeric custom name; map mode still uses its screen position.
 */
public final class DisplayResolver {
	private static final List<DisplayScope> SCOPES = List.of(new AllSlotsScope());

	private DisplayResolver() {
	}

	/** @return the local display for this slot, or empty if the slot should look vanilla. */
	public static Optional<SlotDisplay> resolve(class_465<?> screen, class_1735 slot) {
		if (slot == null || !slot.method_7681()) {
			return Optional.empty();
		}

		OptionalInt position = OptionalInt.empty();
		for (DisplayScope scope : SCOPES) {
			position = scope.positionOf(screen, slot);
			if (position.isPresent()) {
				break;
			}
		}
		if (position.isEmpty()) {
			return Optional.empty();
		}

		return resolve(slot.method_7677(), position.getAsInt());
	}

	/** Resolves a stack using a zero-based repeating display position. */
	public static Optional<SlotDisplay> resolve(class_1799 stack, int position) {
		if (stack == null || stack.method_7960()) {
			return Optional.empty();
		}

		VeloraConfig config = VeloraConfig.get();
		return switch (config.mode) {
			case ITEM_NAMES -> resolveItemName(config, stack, position);
			case MAPS -> resolveMap(config, stack, position);
		};
	}

	/** Returns the selected LOSE item's model id for WIN/LOSE stacks when the visual toggle is on. */
	public static Optional<class_2960> winLoseModelId(class_1799 stack) {
		if (stack == null || stack.method_7960()) {
			return Optional.empty();
		}

		VeloraConfig config = VeloraConfig.get();
		if (!config.winLoseEnabled) {
			return Optional.empty();
		}

		String itemId = class_7923.field_41178.method_10221(stack.method_7909()).toString();
		if (!itemId.equals(config.winItem) && !itemId.equals(config.loseItem)) {
			return Optional.empty();
		}

		class_2960 loseId = config.loseItemId();
		if (loseId == null || !class_7923.field_41178.method_10250(loseId)) {
			return Optional.empty();
		}
		class_1799 loseStack = new class_1799(class_7923.field_41178.method_63535(loseId));
		return Optional.ofNullable(loseStack.method_58694(class_9334.field_54199));
	}

	private static Optional<SlotDisplay> resolveItemName(VeloraConfig config, class_1799 stack, int position) {
		String itemId = class_7923.field_41178.method_10221(stack.method_7909()).toString();
		DisplayPattern pattern = config.pattern;
		String realName = stack.method_58694(class_9334.field_49631) == null
				? null
				: stack.method_58694(class_9334.field_49631).getString().trim();
		if (realName == null || !realName.matches("[1-9]")) {
			return Optional.empty();
		}
		int namePosition = Integer.parseInt(realName) - 1;

		int number;
		if (itemId.equals(config.item1)) {
			number = pattern.lowerNumber(namePosition);
		} else if (itemId.equals(config.item2)) {
			number = pattern.higherNumber(namePosition);
		} else {
			return Optional.empty();
		}
		return Optional.of(new SlotDisplay(String.valueOf(number), number, null));
	}

	private static Optional<SlotDisplay> resolveMap(VeloraConfig config, class_1799 stack, int position) {
		if (!stack.method_31574(class_1802.field_8204)) {
			return Optional.empty();
		}
		class_9209 mapId = stack.method_58694(class_9334.field_49646);
		// Only maps whose real server id is one of the nine known ids are restyled.
		if (mapId == null || MapIds.knownMapNumber(mapId.comp_2315()) < 0) {
			return Optional.empty();
		}

		int number = config.pattern.number(position);
		return Optional.of(new SlotDisplay(
				"Map " + number,
				number,
				MapArt.texture(number, config.map9LocalOverride)));
	}
}
